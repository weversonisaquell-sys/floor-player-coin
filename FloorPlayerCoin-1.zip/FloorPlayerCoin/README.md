# FloorPlayerCoin — Spidey 3D (PSP / PPSSPP)

## O que mudou nesta versão

- **Modelo trocado** pelo `Spidey.fbx` enviado (spider.zip), com as texturas
  `Body.jpg` e `Legs.png`. O modelo foi decimado (~4300 → ~320 vértices no
  total, divididos em grupo "corpo" e grupo "pernas", um por textura) pra
  caber bem no PSP.
- **Animações reais** adicionadas a partir dos FBX do Mixamo:
  - `Ninja Idle.fbx` → parado (idle)
  - `Walking.fbx` → andando
  - `Mma Kick.fbx` → chute (botão Quadrado)
  Cada uma foi "assada" em 8 poses-chave (`ANIM_FRAMES` em `model_data.h`)
  e o jogo interpola entre elas em tempo real (`blendPose` em `main.c`)
  pra ficar suave mesmo com poucos frames guardados.
- **Controle consertado**: o código antigo só lia o analógico (`pad.Lx/Ly`).
  As setinhas (D-pad) nunca eram lidas — por isso não dava pra andar com
  elas. Agora o jogo usa o analógico se ele estiver fora da zona morta, e
  cai pro D-pad automaticamente caso contrário.

## Estrutura

```
src/main.c           - loop do jogo, câmera, física, controle, animação
src/model_data.c/h   - geometria + poses de animação (gerado a partir do FBX)
src/texture_data.c/h - as duas texturas convertidas pra RGB565 128x128
src/Makefile
```

## Compilar

Veja o comando de compilação nas instruções que acompanham esta entrega
(via GitHub Actions ou terminal com o PSPSDK instalado).
