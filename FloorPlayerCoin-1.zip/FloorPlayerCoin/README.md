# Spidey 3D — jogo PSP em terceira pessoa

Jogo 3D em C (pspsdk) para PSP/PPSSPP: chão verde, câmera em terceira pessoa
atrás do personagem (modelo do Homem-Aranha, baixo-poly, texturizado),
pulo e soco.

Como não é possível compilar MIPS sem o toolchain PSPSDK, este pacote vem
como **código-fonte** + um **GitHub Actions** já configurado para compilar
sozinho na nuvem — dá pra fazer tudo pelo celular, sem PC.

## Passo 1 — Subir o projeto pro GitHub (pelo celular)

1. Abra o app do GitHub (ou o site pelo navegador) logado como
   `weversonisaquell-sys`.
2. Crie um repositório novo, por exemplo `floor-player-coin`.
3. Suba TODOS os arquivos desta pasta mantendo a estrutura:
   - `.github/workflows/build.yml`
   - `src/main.c`
   - `src/Makefile`
   (No app do GitHub: "Add file" → "Upload files", ou arraste a pasta
   inteira se estiver usando o site no navegador do celular.)

## Passo 2 — Deixar o GitHub compilar

1. Depois do upload (commit na branch `main`), vá na aba **Actions** do
   repositório.
2. O workflow "Build PSP EBOOT" roda sozinho. Se não rodar, toque em
   **Run workflow**.
3. Espere terminar (ícone verde ✅).
4. Toque no run finalizado → em **Artifacts**, baixe
   `FloorPlayerCoin-EBOOT.zip`. Dentro dele está o `EBOOT.PBP` já compilado.

## Passo 3 — Onde colocar no PPSSPP

O PPSSPP lê jogos de uma pasta de "memory stick" (`ms0`). Dentro dela:

```
PSP/
└── GAME/
    └── FloorPlayerCoin/
        └── EBOOT.PBP
```

1. No app PPSSPP, vá em **Configurações → Sistema → Alterar pasta do
   Memory Stick** para ver/definir onde fica essa pasta no seu aparelho
   (geralmente algo como
   `Android/data/org.ppsspp.ppsspp/files/PSP/GAME/`, ou uma pasta que
   você escolheu no armazenamento do celular).
2. Dentro de `PSP/GAME/`, crie uma pasta chamada `FloorPlayerCoin`
   (o nome da pasta pode ser qualquer um, é só o identificador).
3. Coloque o `EBOOT.PBP` baixado do Passo 2 dentro dessa pasta.
4. Abra o PPSSPP → a lista de jogos deve mostrar "Floor Player Coin".
   Toque para abrir.

## Controles

- Analógico (joystick): anda. O personagem gira pra encarar a direção.
- X: pula.
- Quadrado: soca (dá um pequeno avanço pra frente e mostra um flash branco
  de impacto).

## Sobre o modelo 3D

O modelo original (baixado da internet, formato .glb) tinha ~18.600
vértices e uma textura de 4096x4096 — pesado demais pro PSP. Ele foi
reduzido pra ~500 vértices / ~1000 triângulos e a textura foi
redimensionada pra 128x128, convertida pro formato de cor do PSP
(RGB565). Os dados já vêm prontos em `model_data.c/h` e
`texture_data.c/h` — não precisa converter nada, só compilar.

Como o modelo não tem animação (é uma pose fixa / "T-pose" do arquivo
original), o personagem anda sem animação de perna e o soco é simulado
com um avanço rápido pra frente + um flash de impacto, em vez de um
braço se mexendo de verdade.

## Próximos passos possíveis

Dá pra evoluir: animação de fato (precisa de um modelo com clips de
animação), colisão com obstáculos, câmera com zoom, som, HUD, inimigos.
