#ifndef MODEL_DATA_H
#define MODEL_DATA_H

typedef struct {
    float u, v;
    float x, y, z;
} ModelVertex;

#define SPIDEY_VERTEX_COUNT 501
#define SPIDEY_INDEX_COUNT 1018

extern ModelVertex spidey_vertices[SPIDEY_VERTEX_COUNT];
extern unsigned short spidey_indices[SPIDEY_INDEX_COUNT];

#endif
