#ifndef MODEL_DATA_H
#define MODEL_DATA_H

typedef struct {
    float u, v;
    float x, y, z;
} ModelVertex;

#define ANIM_FRAMES 8

#define BODY_VERTEX_COUNT 187
#define LEGS_VERTEX_COUNT 136
#define BODY_IDLE_COUNT (BODY_VERTEX_COUNT * ANIM_FRAMES)
#define LEGS_IDLE_COUNT (LEGS_VERTEX_COUNT * ANIM_FRAMES)
#define BODY_WALK_COUNT (BODY_VERTEX_COUNT * ANIM_FRAMES)
#define LEGS_WALK_COUNT (LEGS_VERTEX_COUNT * ANIM_FRAMES)
#define BODY_PUNCH_COUNT (BODY_VERTEX_COUNT * ANIM_FRAMES)
#define LEGS_PUNCH_COUNT (LEGS_VERTEX_COUNT * ANIM_FRAMES)

#define BODY_INDEX_COUNT 840
#define LEGS_INDEX_COUNT 627

#define IDLE_CLIP_DURATION 3.333333f
#define WALK_CLIP_DURATION 1.033333f
#define PUNCH_CLIP_DURATION 1.566667f

/* each *_idle/_walk/_punch array holds ANIM_FRAMES consecutive poses of
   the same vertex layout (frame f, vertex i -> index f*COUNT + i) */
extern ModelVertex body_idle[BODY_IDLE_COUNT];
extern ModelVertex body_walk[BODY_WALK_COUNT];
extern ModelVertex body_punch[BODY_PUNCH_COUNT];

extern ModelVertex legs_idle[LEGS_IDLE_COUNT];
extern ModelVertex legs_walk[LEGS_WALK_COUNT];
extern ModelVertex legs_punch[LEGS_PUNCH_COUNT];

extern unsigned short body_indices[BODY_INDEX_COUNT];
extern unsigned short legs_indices[LEGS_INDEX_COUNT];

#endif
