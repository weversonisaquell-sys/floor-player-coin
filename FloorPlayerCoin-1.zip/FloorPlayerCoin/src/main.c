#include <pspkernel.h>
#include <pspdisplay.h>
#include <pspctrl.h>
#include <pspgu.h>
#include <pspgum.h>
#include <math.h>

#include "model_data.h"
#include "texture_data.h"

PSP_MODULE_INFO("Spidey3D", 0, 1, 0);
PSP_MAIN_THREAD_ATTR(THREAD_ATTR_USER);

#define BUF_WIDTH   512
#define SCR_WIDTH   480
#define SCR_HEIGHT  272

static unsigned int __attribute__((aligned(16))) list[262144];

typedef struct {
    unsigned int color;
    float x, y, z;
} ColorVertex;

/* scratch buffers: current (blended) pose, rebuilt every frame */
static ModelVertex bodyBuf[BODY_VERTEX_COUNT] __attribute__((aligned(16)));
static ModelVertex legsBuf[LEGS_VERTEX_COUNT] __attribute__((aligned(16)));

typedef enum { STATE_IDLE, STATE_WALK, STATE_PUNCH } CharState;

/* ---- callback de saida (necessario em todo homebrew PSP) ---- */
int exit_callback(int arg1, int arg2, void *common) {
    sceKernelExitGame();
    return 0;
}

int CallbackThread(SceSize args, void *argp) {
    int cbid = sceKernelCreateCallback("Exit Callback", exit_callback, NULL);
    sceKernelRegisterExitCallback(cbid);
    sceKernelSleepThreadCB();
    return 0;
}

int SetupCallbacks(void) {
    int thid = sceKernelCreateThread("update_thread", CallbackThread, 0x11, 0xFA0, 0, 0);
    if (thid >= 0) sceKernelStartThread(thid, 0, 0);
    return thid;
}

/* ---- chao verde (um grande quad) ---- */
void drawFloor(void) {
    sceGuDisable(GU_TEXTURE_2D);

    ColorVertex* v = (ColorVertex*)sceGuGetMemory(4 * sizeof(ColorVertex));
    const float S = 50.0f;
    unsigned int green = 0xFF339933; /* ABGR: verde solido */

    v[0].color = green; v[0].x = -S; v[0].y = 0; v[0].z = -S;
    v[1].color = green; v[1].x =  S; v[1].y = 0; v[1].z = -S;
    v[2].color = green; v[2].x = -S; v[2].y = 0; v[2].z =  S;
    v[3].color = green; v[3].x =  S; v[3].y = 0; v[3].z =  S;

    sceGumDrawArray(GU_TRIANGLE_STRIP,
        GU_COLOR_8888 | GU_VERTEX_32BITF | GU_TRANSFORM_3D,
        4, 0, v);
}

/* ---- monta a pose atual (interpolando entre 2 frames) num buffer ---- */
static void blendPose(ModelVertex* dst, const ModelVertex* src, int vertCount,
                       int frameA, int frameB, float blend) {
    int i;
    for (i = 0; i < vertCount; i++) {
        const ModelVertex* a = &src[frameA * vertCount + i];
        const ModelVertex* b = &src[frameB * vertCount + i];
        dst[i].u = a->u;
        dst[i].v = a->v;
        dst[i].x = a->x + (b->x - a->x) * blend;
        dst[i].y = a->y + (b->y - a->y) * blend;
        dst[i].z = a->z + (b->z - a->z) * blend;
    }
}

/* ---- desenha as duas partes do Homem-Aranha (corpo + pernas), cada uma com sua textura ---- */
void drawSpidey(void) {
    sceGuEnable(GU_TEXTURE_2D);
    sceGuTexFunc(GU_TFX_REPLACE, GU_TCC_RGB);
    sceGuTexFilter(GU_LINEAR, GU_LINEAR);
    sceGuTexWrap(GU_CLAMP, GU_CLAMP);
    sceGuTexScale(1.0f, 1.0f);
    sceGuTexOffset(0.0f, 0.0f);

    sceGuTexMode(GU_PSM_5650, 0, 0, 0);
    sceGuTexImage(0, BODY_TEX_WIDTH, BODY_TEX_HEIGHT, BODY_TEX_WIDTH, body_texture);
    sceGumDrawArray(GU_TRIANGLES,
        GU_TEXTURE_32BITF | GU_VERTEX_32BITF | GU_TRANSFORM_3D | GU_INDEX_16BIT,
        BODY_INDEX_COUNT, body_indices, bodyBuf);

    sceGuTexImage(0, LEGS_TEX_WIDTH, LEGS_TEX_HEIGHT, LEGS_TEX_WIDTH, legs_texture);
    sceGumDrawArray(GU_TRIANGLES,
        GU_TEXTURE_32BITF | GU_VERTEX_32BITF | GU_TRANSFORM_3D | GU_INDEX_16BIT,
        LEGS_INDEX_COUNT, legs_indices, legsBuf);
}

/* ---- flash branco de impacto do chute ---- */
void drawPunchFlash(float x, float y, float z) {
    sceGuDisable(GU_TEXTURE_2D);
    ColorVertex* v = (ColorVertex*)sceGuGetMemory(4 * sizeof(ColorVertex));
    const float S = 0.10f;
    unsigned int white = 0xFFFFFFFF;

    v[0].color = white; v[0].x = x - S; v[0].y = y - S; v[0].z = z;
    v[1].color = white; v[1].x = x + S; v[1].y = y - S; v[1].z = z;
    v[2].color = white; v[2].x = x - S; v[2].y = y + S; v[2].z = z;
    v[3].color = white; v[3].x = x + S; v[3].y = y + S; v[3].z = z;

    sceGumDrawArray(GU_TRIANGLE_STRIP,
        GU_COLOR_8888 | GU_VERTEX_32BITF | GU_TRANSFORM_3D,
        4, 0, v);
}

int main(void) {
    SetupCallbacks();

    void* fbp0 = (void*)0;
    void* fbp1 = (void*)(512 * 272 * 4);
    void* zbp  = (void*)(512 * 272 * 4 * 2);

    sceGuInit();
    sceGuStart(GU_DIRECT, list);
    sceGuDrawBuffer(GU_PSM_8888, fbp0, BUF_WIDTH);
    sceGuDispBuffer(SCR_WIDTH, SCR_HEIGHT, fbp1, BUF_WIDTH);
    sceGuDepthBuffer(zbp, BUF_WIDTH);
    sceGuOffset(2048 - (SCR_WIDTH / 2), 2048 - (SCR_HEIGHT / 2));
    sceGuViewport(2048, 2048, SCR_WIDTH, SCR_HEIGHT);
    sceGuDepthRange(0xc350, 0x2710);
    sceGuScissor(0, 0, SCR_WIDTH, SCR_HEIGHT);
    sceGuEnable(GU_SCISSOR_TEST);
    sceGuDepthFunc(GU_GEQUAL);
    sceGuEnable(GU_DEPTH_TEST);
    sceGuFrontFace(GU_CW);
    sceGuShadeModel(GU_SMOOTH);
    sceGuEnable(GU_CLIP_PLANES);
    sceGuFinish();
    sceGuSync(0, 0);

    sceDisplayWaitVblankStart();
    sceGuDisplay(GU_TRUE);

    /* ---- estado do jogo ---- */
    float playerX = 0.0f, playerZ = 0.0f;
    float playerY = 0.0f;      /* altura (chao = 0) */
    float velY = 0.0f;
    int grounded = 1;

    float yaw = 0.0f;          /* direcao que o player olha, em radianos */
    const float moveSpeed = 1.6f;   /* unidades por segundo (personagem ~1.8 unidades de altura) */
    const float turnLerp  = 0.20f;  /* suavidade do giro */
    const float gravity   = 6.0f;
    const float jumpSpeed = 3.0f;

    /* ---- animacao ---- */
    CharState state = STATE_IDLE;
    CharState prevState = STATE_IDLE;
    float animTime = 0.0f;

    int prevButtons = 0;

    SceCtrlData pad;

    while (1) {
        sceCtrlReadBufferPositive(&pad, 1);

        float dt = 1.0f / 60.0f;

        /* ---- movimento: analogico (Lx/Ly) OU direcional (D-pad) ---- */
        float ax = (pad.Lx - 128) / 128.0f;
        float ay = (pad.Ly - 128) / 128.0f;
        float amag = sqrtf(ax * ax + ay * ay);

        if (amag > 0.20f) {
            if (amag > 1.0f) { ax /= amag; ay /= amag; }
        } else {
            ax = 0.0f; ay = 0.0f;
            if (pad.Buttons & PSP_CTRL_UP)    ay -= 1.0f;
            if (pad.Buttons & PSP_CTRL_DOWN)  ay += 1.0f;
            if (pad.Buttons & PSP_CTRL_LEFT)  ax -= 1.0f;
            if (pad.Buttons & PSP_CTRL_RIGHT) ax += 1.0f;
            float dmag = sqrtf(ax * ax + ay * ay);
            if (dmag > 1.0f) { ax /= dmag; ay /= dmag; }
        }

        float mag = sqrtf(ax * ax + ay * ay);
        int moving = (mag > 0.15f);

        if (moving) {
            float dirX = ax;
            float dirZ = ay;
            float targetYaw = atan2f(dirX, -dirZ);

            /* gira suavemente ate a direcao alvo (caminho mais curto) */
            float diff = targetYaw - yaw;
            while (diff > M_PI)  diff -= 2.0f * M_PI;
            while (diff < -M_PI) diff += 2.0f * M_PI;
            yaw += diff * turnLerp;

            playerX += dirX * moveSpeed * mag * dt;
            playerZ += dirZ * moveSpeed * mag * dt;
        }

        /* ---- pulo (X) ---- */
        if ((pad.Buttons & PSP_CTRL_CROSS) && !(prevButtons & PSP_CTRL_CROSS) && grounded) {
            velY = jumpSpeed;
            grounded = 0;
        }

        /* ---- chute (quadrado) ---- */
        if ((pad.Buttons & PSP_CTRL_SQUARE) && !(prevButtons & PSP_CTRL_SQUARE) && state != STATE_PUNCH) {
            state = STATE_PUNCH;
            animTime = 0.0f;
        }

        prevButtons = pad.Buttons;

        /* ---- fisica vertical (gravidade) ---- */
        velY -= gravity * dt;
        playerY += velY * dt;
        if (playerY <= 0.0f) {
            playerY = 0.0f;
            velY = 0.0f;
            grounded = 1;
        }

        /* ---- maquina de estados de animacao ---- */
        if (state == STATE_PUNCH) {
            animTime += dt;
            if (animTime >= PUNCH_CLIP_DURATION) {
                state = moving ? STATE_WALK : STATE_IDLE;
                animTime = 0.0f;
            }
        } else {
            CharState wanted = moving ? STATE_WALK : STATE_IDLE;
            if (wanted != state) {
                state = wanted;
                animTime = 0.0f;
            } else {
                animTime += dt;
            }
        }
        prevState = state;
        (void)prevState;

        /* ---- escolhe os frames a interpolar para o estado atual ---- */
        const ModelVertex* bodySrc;
        const ModelVertex* legsSrc;
        float clipDur;
        int loopAnim = 1;

        switch (state) {
            case STATE_WALK:
                bodySrc = body_walk; legsSrc = legs_walk; clipDur = WALK_CLIP_DURATION;
                break;
            case STATE_PUNCH:
                bodySrc = body_punch; legsSrc = legs_punch; clipDur = PUNCH_CLIP_DURATION;
                loopAnim = 0;
                break;
            default:
                bodySrc = body_idle; legsSrc = legs_idle; clipDur = IDLE_CLIP_DURATION;
                break;
        }

        float t = loopAnim ? fmodf(animTime, clipDur) : animTime;
        if (t >= clipDur) t = clipDur - 0.0001f;
        if (t < 0.0f) t = 0.0f;

        float phase = (t / clipDur) * ANIM_FRAMES;
        int frameA = (int)phase;
        if (frameA >= ANIM_FRAMES) frameA = ANIM_FRAMES - 1;
        int frameB = loopAnim ? (frameA + 1) % ANIM_FRAMES
                               : (frameA + 1 < ANIM_FRAMES ? frameA + 1 : frameA);
        float blend = phase - frameA;

        blendPose(bodyBuf, bodySrc, BODY_VERTEX_COUNT, frameA, frameB, blend);
        blendPose(legsBuf, legsSrc, LEGS_VERTEX_COUNT, frameA, frameB, blend);

        /* ---- camera em terceira pessoa, atras do player ---- */
        float fwdX = sinf(yaw);
        float fwdZ = -cosf(yaw);
        const float camDist   = 2.2f;
        const float camHeight = 1.1f;

        float camX = playerX - fwdX * camDist;
        float camZ = playerZ - fwdZ * camDist;
        float camY = playerY + camHeight;

        ScePspFVector3 eye    = { camX, camY, camZ };
        ScePspFVector3 center = { playerX, playerY + 0.9f, playerZ };
        ScePspFVector3 up     = { 0.0f, 1.0f, 0.0f };

        /* ---- desenho ---- */
        sceGuStart(GU_DIRECT, list);
        sceGuClearColor(0xFF553311); /* ceu (ABGR) */
        sceGuClearDepth(0);
        sceGuClear(GU_COLOR_BUFFER_BIT | GU_DEPTH_BUFFER_BIT);

        sceGumMatrixMode(GU_PROJECTION);
        sceGumLoadIdentity();
        sceGumPerspective(60.0f, (float)SCR_WIDTH / (float)SCR_HEIGHT, 0.1f, 500.0f);

        sceGumMatrixMode(GU_VIEW);
        sceGumLoadIdentity();
        sceGumLookAt(&eye, &center, &up);

        /* chao */
        sceGumMatrixMode(GU_MODEL);
        sceGumLoadIdentity();
        drawFloor();

        /* player */
        sceGumMatrixMode(GU_MODEL);
        sceGumLoadIdentity();
        ScePspFVector3 pTrans = { playerX, playerY, playerZ };
        sceGumTranslate(&pTrans);
        sceGumRotateY(yaw);
        drawSpidey();

        /* flash do impacto do chute, perto do fim da animacao */
        if (state == STATE_PUNCH && animTime >= PUNCH_CLIP_DURATION * 0.55f &&
            animTime <= PUNCH_CLIP_DURATION * 0.85f) {
            sceGumMatrixMode(GU_MODEL);
            sceGumLoadIdentity();
            drawPunchFlash(playerX + fwdX * 0.65f, playerY + 0.45f, playerZ + fwdZ * 0.65f);
        }

        sceGuFinish();
        sceGuSync(0, 0);

        sceDisplayWaitVblankStart();
        sceGuSwapBuffers();
    }

    sceGuTerm();
    sceKernelExitGame();
    return 0;
}
