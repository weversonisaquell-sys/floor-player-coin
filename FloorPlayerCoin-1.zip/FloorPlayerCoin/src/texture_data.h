#ifndef TEXTURE_DATA_H
#define TEXTURE_DATA_H

#define SPIDEY_TEX_WIDTH 128
#define SPIDEY_TEX_HEIGHT 128

extern unsigned short spidey_texture[SPIDEY_TEX_WIDTH * SPIDEY_TEX_HEIGHT];

#endif
