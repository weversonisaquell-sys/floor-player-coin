#ifndef MODEL_DATA_H
#define MODEL_DATA_H

typedef struct { float u, v, x, y, z; } ModelVertex;

#define BODY_VERTEX_COUNT 206
#define LEGS_VERTEX_COUNT 136
#define BODY_INDEX_COUNT 897
#define LEGS_INDEX_COUNT 657

#define ANIM_FRAMES 24
#define BODY_IDLE_COUNT  (BODY_VERTEX_COUNT * ANIM_FRAMES)
#define LEGS_IDLE_COUNT  (LEGS_VERTEX_COUNT * ANIM_FRAMES)
#define BODY_WALK_COUNT  (BODY_VERTEX_COUNT * ANIM_FRAMES)
#define LEGS_WALK_COUNT  (LEGS_VERTEX_COUNT * ANIM_FRAMES)
#define BODY_PUNCH_COUNT (BODY_VERTEX_COUNT * ANIM_FRAMES)
#define LEGS_PUNCH_COUNT (LEGS_VERTEX_COUNT * ANIM_FRAMES)

#define IDLE_CLIP_DURATION  3.333333f
#define WALK_CLIP_DURATION  1.033333f
#define PUNCH_CLIP_DURATION 1.566667f

extern ModelVertex body_idle[BODY_IDLE_COUNT];
extern ModelVertex legs_idle[LEGS_IDLE_COUNT];
extern ModelVertex body_walk[BODY_WALK_COUNT];
extern ModelVertex legs_walk[LEGS_WALK_COUNT];
extern ModelVertex body_punch[BODY_PUNCH_COUNT];
extern ModelVertex legs_punch[LEGS_PUNCH_COUNT];

extern unsigned short body_indices[BODY_INDEX_COUNT];
extern unsigned short legs_indices[LEGS_INDEX_COUNT];

#endif
