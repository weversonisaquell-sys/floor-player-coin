#ifndef BACKFLIP_DATA_H
#define BACKFLIP_DATA_H

#include "model_data.h"

/* Animacao de mortal para tras (Backflip.fbx do Mixamo) assada no Homem-Aranha, sem deslocamento.
   32 poses igualmente espacadas (ultima pose = fim do clipe).
   Gerado do Backflip.fbx (Mixamo), reamostrado pra bater com a topologia nova do model_data. */
#define BACKFLIP_FRAMES 32
#define BODY_BACKFLIP_COUNT (BODY_VERTEX_COUNT * BACKFLIP_FRAMES)
#define LEGS_BACKFLIP_COUNT (LEGS_VERTEX_COUNT * BACKFLIP_FRAMES)
#define BACKFLIP_CLIP_DURATION 2.150000f

extern ModelVertex body_backflip[BODY_BACKFLIP_COUNT];
extern ModelVertex legs_backflip[LEGS_BACKFLIP_COUNT];

#endif
