#ifndef TEXTURE_DATA_H
#define TEXTURE_DATA_H

#define BODY_TEX_WIDTH  256
#define BODY_TEX_HEIGHT 256
#define LEGS_TEX_WIDTH  256
#define LEGS_TEX_HEIGHT 256

extern unsigned short body_texture[BODY_TEX_WIDTH * BODY_TEX_HEIGHT];
extern unsigned short legs_texture[LEGS_TEX_WIDTH * LEGS_TEX_HEIGHT];

#endif
