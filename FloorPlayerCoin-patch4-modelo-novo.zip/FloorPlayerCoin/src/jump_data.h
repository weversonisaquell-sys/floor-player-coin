#ifndef JUMP_DATA_H
#define JUMP_DATA_H

#include "model_data.h"

/* Animacao de pulo (Jumping.fbx do Mixamo) assada no Homem-Aranha.
   24 poses igualmente espacadas (ultima pose = fim do clipe).
   Gerado do Jumping.fbx (Mixamo), reamostrado pra bater com a topologia nova do model_data. */
#define JUMP_FRAMES 24
#define BODY_JUMP_COUNT (BODY_VERTEX_COUNT * JUMP_FRAMES)
#define LEGS_JUMP_COUNT (LEGS_VERTEX_COUNT * JUMP_FRAMES)
#define JUMP_CLIP_DURATION 1.883333f

extern ModelVertex body_jump[BODY_JUMP_COUNT];
extern ModelVertex legs_jump[LEGS_JUMP_COUNT];

#endif
