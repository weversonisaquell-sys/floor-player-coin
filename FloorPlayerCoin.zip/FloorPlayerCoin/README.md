# Floor Player Coin — base de jogo PSP

Base mínima em C (pspsdk) para PSP/PPSSPP: um painel com **chão**, **player**
(quadrado branco, anda com a cruzeta) e **moeda** (some ao encostar).

Como não é possível compilar MIPS sem o toolchain PSPSDK, este pacote vem
como **código-fonte** + um **GitHub Actions** já configurado para compilar
sozinho na nuvem — dá pra fazer tudo pelo celular, sem PC.

## Passo 1 — Subir o projeto pro GitHub (pelo celular)

1. Abra o app do GitHub (ou o site pelo navegador) logado como
   `weversonisaquell-sys`.
2. Crie um repositório novo, por exemplo `floor-player-coin`.
3. Suba TODOS os arquivos desta pasta mantendo a estrutura:
   - `.github/workflows/build.yml`
   - `src/main.c`
   - `src/Makefile`
   (No app do GitHub: "Add file" → "Upload files", ou arraste a pasta
   inteira se estiver usando o site no navegador do celular.)

## Passo 2 — Deixar o GitHub compilar

1. Depois do upload (commit na branch `main`), vá na aba **Actions** do
   repositório.
2. O workflow "Build PSP EBOOT" roda sozinho. Se não rodar, toque em
   **Run workflow**.
3. Espere terminar (ícone verde ✅).
4. Toque no run finalizado → em **Artifacts**, baixe
   `FloorPlayerCoin-EBOOT.zip`. Dentro dele está o `EBOOT.PBP` já compilado.

## Passo 3 — Onde colocar no PPSSPP

O PPSSPP lê jogos de uma pasta de "memory stick" (`ms0`). Dentro dela:

```
PSP/
└── GAME/
    └── FloorPlayerCoin/
        └── EBOOT.PBP
```

1. No app PPSSPP, vá em **Configurações → Sistema → Alterar pasta do
   Memory Stick** para ver/definir onde fica essa pasta no seu aparelho
   (geralmente algo como
   `Android/data/org.ppsspp.ppsspp/files/PSP/GAME/`, ou uma pasta que
   você escolheu no armazenamento do celular).
2. Dentro de `PSP/GAME/`, crie uma pasta chamada `FloorPlayerCoin`
   (o nome da pasta pode ser qualquer um, é só o identificador).
3. Coloque o `EBOOT.PBP` baixado do Passo 2 dentro dessa pasta.
4. Abra o PPSSPP → a lista de jogos deve mostrar "Floor Player Coin".
   Toque para abrir.

## Controles

- Cruzeta: move o player.
- Objetivo: encostar o player na moeda (ela some quando colide).

## Próximos passos possíveis

A partir dessa base dá pra evoluir: sprites com textura em vez de
retângulos sólidos, pulo/gravidade, várias moedas, som, menu, etc.
