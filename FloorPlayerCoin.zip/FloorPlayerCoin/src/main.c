#include <pspkernel.h>
#include <pspdisplay.h>
#include <pspctrl.h>
#include <pspgu.h>
#include <pspgum.h>

PSP_MODULE_INFO("FloorPlayerCoin", 0, 1, 0);
PSP_MAIN_THREAD_ATTR(THREAD_ATTR_USER);

#define BUF_WIDTH   512
#define SCR_WIDTH   480
#define SCR_HEIGHT  272

static unsigned int __attribute__((aligned(16))) list[262144];

typedef struct {
    unsigned int color;
    float x, y, z;
} Vertex;

/* ---- callback de saida (necessario em todo homebrew PSP) ---- */
int exit_callback(int arg1, int arg2, void *common) {
    sceKernelExitGame();
    return 0;
}

int CallbackThread(SceSize args, void *argp) {
    int cbid = sceKernelCreateCallback("Exit Callback", exit_callback, NULL);
    sceKernelRegisterExitCallback(cbid);
    sceKernelSleepThreadCB();
    return 0;
}

int SetupCallbacks(void) {
    int thid = sceKernelCreateThread("update_thread", CallbackThread, 0x11, 0xFA0, 0, 0);
    if (thid >= 0) sceKernelStartThread(thid, 0, 0);
    return thid;
}

/* ---- desenha um retangulo solido usando GU_SPRITES (2 vertices: cantos) ---- */
void drawRect(float x, float y, float w, float h, unsigned int color) {
    Vertex* vertices = (Vertex*)sceGuGetMemory(2 * sizeof(Vertex));
    vertices[0].color = color;
    vertices[0].x = x;     vertices[0].y = y;     vertices[0].z = 0;
    vertices[1].color = color;
    vertices[1].x = x + w; vertices[1].y = y + h; vertices[1].z = 0;
    sceGumDrawArray(GU_SPRITES, GU_COLOR_8888 | GU_VERTEX_32BITF | GU_TRANSFORM_2D, 2, 0, vertices);
}

int main(void) {
    SetupCallbacks();

    void* fbp0 = (void*)0;
    void* fbp1 = (void*)(512 * 272 * 4);
    void* zbp  = (void*)(512 * 272 * 4 * 2);

    sceGuInit();
    sceGuStart(GU_DIRECT, list);
    sceGuDrawBuffer(GU_PSM_8888, fbp0, BUF_WIDTH);
    sceGuDispBuffer(SCR_WIDTH, SCR_HEIGHT, fbp1, BUF_WIDTH);
    sceGuDepthBuffer(zbp, BUF_WIDTH);
    sceGuOffset(2048 - (SCR_WIDTH / 2), 2048 - (SCR_HEIGHT / 2));
    sceGuViewport(2048, 2048, SCR_WIDTH, SCR_HEIGHT);
    sceGuDepthRange(65535, 0);
    sceGuScissor(0, 0, SCR_WIDTH, SCR_HEIGHT);
    sceGuEnable(GU_SCISSOR_TEST);
    sceGuFrontFace(GU_CW);
    sceGuShadeModel(GU_SMOOTH);
    sceGuDisable(GU_DEPTH_TEST);
    sceGuFinish();
    sceGuSync(0, 0);

    sceDisplayWaitVblankStart();
    sceGuDisplay(GU_TRUE);

    /* ---- estado do jogo (base minima: player + moeda + chao) ---- */
    float playerX = 200.0f, playerY = 190.0f;
    const float playerSize = 20.0f;

    float coinX = 350.0f, coinY = 210.0f;
    const float coinSize = 14.0f;
    int coinCollected = 0;

    const float floorY = 232.0f;
    const float floorH = 40.0f;
    const float speed = 3.0f;

    SceCtrlData pad;

    while (1) {
        sceCtrlReadBufferPositive(&pad, 1);

        if (pad.Buttons & PSP_CTRL_LEFT)  playerX -= speed;
        if (pad.Buttons & PSP_CTRL_RIGHT) playerX += speed;
        if (pad.Buttons & PSP_CTRL_UP)    playerY -= speed;
        if (pad.Buttons & PSP_CTRL_DOWN)  playerY += speed;

        /* limites da tela / chao */
        if (playerX < 10.0f) playerX = 10.0f;
        if (playerX > SCR_WIDTH - playerSize - 10.0f) playerX = SCR_WIDTH - playerSize - 10.0f;
        if (playerY < 20.0f) playerY = 20.0f;
        if (playerY > floorY - playerSize) playerY = floorY - playerSize;

        /* colisao simples player x moeda */
        if (!coinCollected) {
            float dx = (playerX + playerSize / 2) - (coinX + coinSize / 2);
            float dy = (playerY + playerSize / 2) - (coinY + coinSize / 2);
            if (dx * dx + dy * dy < 400.0f) coinCollected = 1;
        }

        sceGuStart(GU_DIRECT, list);
        sceGuClearColor(0x00553311); /* fundo (ABGR) */
        sceGuClear(GU_COLOR_BUFFER_BIT);

        sceGuDisable(GU_TEXTURE_2D);

        /* chao */
        drawRect(0, floorY, SCR_WIDTH, floorH, 0xFF228855);

        /* moeda (se ainda nao coletada) */
        if (!coinCollected) {
            drawRect(coinX, coinY, coinSize, coinSize, 0xFF00D7FF);
        }

        /* player */
        drawRect(playerX, playerY, playerSize, playerSize, 0xFFFFFFFF);

        sceGuFinish();
        sceGuSync(0, 0);

        sceDisplayWaitVblankStart();
        sceGuSwapBuffers();
    }

    sceGuTerm();
    sceKernelExitGame();
    return 0;
}
