#ifndef JUMP_DATA_H
#define JUMP_DATA_H

#include "model_data.h"

/* Animacao de pulo (Jumping.fbx do Mixamo) assada no Homem-Aranha.
   24 poses igualmente espacadas de 0 ate JUMP_CLIP_DURATION (a ultima pose
   e o fim do clipe, sem loop). Ja vem com UV corrigido e centralizada igual
   ao clipe de caminhada, entao NAO passa pelo recenterClip. */
#define JUMP_FRAMES 24
#define BODY_JUMP_COUNT (BODY_VERTEX_COUNT * JUMP_FRAMES)
#define LEGS_JUMP_COUNT (LEGS_VERTEX_COUNT * JUMP_FRAMES)
#define JUMP_CLIP_DURATION 1.883333f

extern ModelVertex body_jump[BODY_JUMP_COUNT];
extern ModelVertex legs_jump[LEGS_JUMP_COUNT];

#endif
