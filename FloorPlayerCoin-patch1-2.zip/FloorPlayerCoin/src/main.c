#include <pspkernel.h>
#include <pspdisplay.h>
#include <pspctrl.h>
#include <pspgu.h>
#include <pspgum.h>
#include <math.h>
#include <string.h>

#include "model_data.h"
#include "texture_data.h"
#include "jump_data.h"

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

PSP_MODULE_INFO("Spidey3D", 0, 1, 0);
PSP_MAIN_THREAD_ATTR(THREAD_ATTR_USER);

#define BUF_WIDTH   512
#define SCR_WIDTH   480
#define SCR_HEIGHT  272

static unsigned int __attribute__((aligned(16))) list[262144];

typedef struct {
    unsigned int color;
    float x, y, z;
} ColorVertex;

/* scratch buffers: current (blended) pose, rebuilt every frame */
static ModelVertex bodyBuf[BODY_VERTEX_COUNT] __attribute__((aligned(16)));
static ModelVertex legsBuf[LEGS_VERTEX_COUNT] __attribute__((aligned(16)));

typedef enum { STATE_IDLE, STATE_WALK, STATE_PUNCH, STATE_JUMP } CharState;
typedef enum { GS_TITLE, GS_CUTSCENE, GS_PLAY } GameState;

/* ------------------------------------------------------------------ */
/* Callback de saida (necessario em todo homebrew PSP)                 */
/* ------------------------------------------------------------------ */
int exit_callback(int arg1, int arg2, void *common) {
    sceKernelExitGame();
    return 0;
}

int CallbackThread(SceSize args, void *argp) {
    int cbid = sceKernelCreateCallback("Exit Callback", exit_callback, NULL);
    sceKernelRegisterExitCallback(cbid);
    sceKernelSleepThreadCB();
    return 0;
}

int SetupCallbacks(void) {
    int thid = sceKernelCreateThread("update_thread", CallbackThread, 0x11, 0xFA0, 0, 0);
    if (thid >= 0) sceKernelStartThread(thid, 0, 0);
    return thid;
}

/* ------------------------------------------------------------------ */
/* Preparacao do modelo (roda uma vez)                                 */
/*  - UV fora de 0..1 (o corpo tinha 4 vertices com v ~ 2.27, e o      */
/*    GU_CLAMP esticava a textura -> "cacos" estranhos no modelo)       */
/*  - recentraliza cada animacao em X/Z: idle e chute vinham com o     */
/*    corpo deslocado do pivo, entao o Aranha girava "fora do eixo"    */
/* ------------------------------------------------------------------ */
static void fixUVs(ModelVertex* a, int n) {
    int i;
    for (i = 0; i < n; i++) {
        if (a[i].u > 1.0f || a[i].u < 0.0f) a[i].u -= floorf(a[i].u);
        if (a[i].v > 1.0f || a[i].v < 0.0f) a[i].v -= floorf(a[i].v);
    }
}

static void recenterClip(ModelVertex* a, int na, ModelVertex* b, int nb) {
    int i;
    double sx = 0.0, sz = 0.0;
    for (i = 0; i < na; i++) { sx += a[i].x; sz += a[i].z; }
    for (i = 0; i < nb; i++) { sx += b[i].x; sz += b[i].z; }
    float mx = (float)(sx / (double)(na + nb));
    float mz = (float)(sz / (double)(na + nb));
    for (i = 0; i < na; i++) { a[i].x -= mx; a[i].z -= mz; }
    for (i = 0; i < nb; i++) { b[i].x -= mx; b[i].z -= mz; }
}

static void prepareModel(void) {
    fixUVs(body_idle,  BODY_IDLE_COUNT);
    fixUVs(body_walk,  BODY_WALK_COUNT);
    fixUVs(body_punch, BODY_PUNCH_COUNT);
    fixUVs(legs_idle,  LEGS_IDLE_COUNT);
    fixUVs(legs_walk,  LEGS_WALK_COUNT);
    fixUVs(legs_punch, LEGS_PUNCH_COUNT);

    recenterClip(body_idle,  BODY_IDLE_COUNT,  legs_idle,  LEGS_IDLE_COUNT);
    recenterClip(body_walk,  BODY_WALK_COUNT,  legs_walk,  LEGS_WALK_COUNT);
    recenterClip(body_punch, BODY_PUNCH_COUNT, legs_punch, LEGS_PUNCH_COUNT);

    sceKernelDcacheWritebackAll();
}

/* ------------------------------------------------------------------ */
/* Cores                                                               */
/* ------------------------------------------------------------------ */
static unsigned int shadeColor(unsigned int c, float k) {
    unsigned int r = (c >>  0) & 0xFF;
    unsigned int g = (c >>  8) & 0xFF;
    unsigned int b = (c >> 16) & 0xFF;
    unsigned int a = (c >> 24) & 0xFF;
    r = (unsigned int)(r * k); if (r > 255) r = 255;
    g = (unsigned int)(g * k); if (g > 255) g = 255;
    b = (unsigned int)(b * k); if (b > 255) b = 255;
    return (a << 24) | (b << 16) | (g << 8) | r;
}

/* ------------------------------------------------------------------ */
/* Modo 2D (tela inicial): coordenadas direto em pixels (0..480/0..272) */
/* ------------------------------------------------------------------ */
#define V2D_FMT (GU_COLOR_8888 | GU_VERTEX_32BITF | GU_TRANSFORM_2D)

static void begin2D(void) {
    sceGuDisable(GU_DEPTH_TEST);
    sceGuDisable(GU_TEXTURE_2D);
    sceGuEnable(GU_BLEND);
    sceGuBlendFunc(GU_ADD, GU_SRC_ALPHA, GU_ONE_MINUS_SRC_ALPHA, 0, 0);
}

static void end2D(void) {
    sceGuDisable(GU_BLEND);
    sceGuEnable(GU_DEPTH_TEST);
}

/* retangulo com cor por canto: topo (c0) e base (c1) */
static void fillRectV(float x, float y, float w, float h, unsigned int c0, unsigned int c1) {
    ColorVertex* v = (ColorVertex*)sceGuGetMemory(4 * sizeof(ColorVertex));
    v[0].color = c0; v[0].x = x;     v[0].y = y;     v[0].z = 0;
    v[1].color = c0; v[1].x = x + w; v[1].y = y;     v[1].z = 0;
    v[2].color = c1; v[2].x = x;     v[2].y = y + h; v[2].z = 0;
    v[3].color = c1; v[3].x = x + w; v[3].y = y + h; v[3].z = 0;
    sceGuDrawArray(GU_TRIANGLE_STRIP, V2D_FMT, 4, 0, v);
}

static void fillRect(float x, float y, float w, float h, unsigned int c) {
    fillRectV(x, y, w, h, c, c);
}

/* ---- fonte bitmap 5x7 (A-Z, 0-9, : / - . !) ---- */
static const unsigned char font5x7[41][7] = {
    {0b01110,0b10001,0b10001,0b11111,0b10001,0b10001,0b10001}, /* A */
    {0b11110,0b10001,0b10001,0b11110,0b10001,0b10001,0b11110}, /* B */
    {0b01110,0b10001,0b10000,0b10000,0b10000,0b10001,0b01110}, /* C */
    {0b11110,0b10001,0b10001,0b10001,0b10001,0b10001,0b11110}, /* D */
    {0b11111,0b10000,0b10000,0b11110,0b10000,0b10000,0b11111}, /* E */
    {0b11111,0b10000,0b10000,0b11110,0b10000,0b10000,0b10000}, /* F */
    {0b01110,0b10001,0b10000,0b10111,0b10001,0b10001,0b01111}, /* G */
    {0b10001,0b10001,0b10001,0b11111,0b10001,0b10001,0b10001}, /* H */
    {0b01110,0b00100,0b00100,0b00100,0b00100,0b00100,0b01110}, /* I */
    {0b00111,0b00010,0b00010,0b00010,0b00010,0b10010,0b01100}, /* J */
    {0b10001,0b10010,0b10100,0b11000,0b10100,0b10010,0b10001}, /* K */
    {0b10000,0b10000,0b10000,0b10000,0b10000,0b10000,0b11111}, /* L */
    {0b10001,0b11011,0b10101,0b10101,0b10001,0b10001,0b10001}, /* M */
    {0b10001,0b11001,0b10101,0b10011,0b10001,0b10001,0b10001}, /* N */
    {0b01110,0b10001,0b10001,0b10001,0b10001,0b10001,0b01110}, /* O */
    {0b11110,0b10001,0b10001,0b11110,0b10000,0b10000,0b10000}, /* P */
    {0b01110,0b10001,0b10001,0b10001,0b10101,0b10010,0b01101}, /* Q */
    {0b11110,0b10001,0b10001,0b11110,0b10100,0b10010,0b10001}, /* R */
    {0b01111,0b10000,0b10000,0b01110,0b00001,0b00001,0b11110}, /* S */
    {0b11111,0b00100,0b00100,0b00100,0b00100,0b00100,0b00100}, /* T */
    {0b10001,0b10001,0b10001,0b10001,0b10001,0b10001,0b01110}, /* U */
    {0b10001,0b10001,0b10001,0b10001,0b10001,0b01010,0b00100}, /* V */
    {0b10001,0b10001,0b10001,0b10101,0b10101,0b11011,0b10001}, /* W */
    {0b10001,0b10001,0b01010,0b00100,0b01010,0b10001,0b10001}, /* X */
    {0b10001,0b10001,0b01010,0b00100,0b00100,0b00100,0b00100}, /* Y */
    {0b11111,0b00001,0b00010,0b00100,0b01000,0b10000,0b11111}, /* Z */
    {0b01110,0b10001,0b10011,0b10101,0b11001,0b10001,0b01110}, /* 0 */
    {0b00100,0b01100,0b00100,0b00100,0b00100,0b00100,0b01110}, /* 1 */
    {0b01110,0b10001,0b00001,0b00010,0b00100,0b01000,0b11111}, /* 2 */
    {0b11110,0b00001,0b00001,0b01110,0b00001,0b00001,0b11110}, /* 3 */
    {0b00010,0b00110,0b01010,0b10010,0b11111,0b00010,0b00010}, /* 4 */
    {0b11111,0b10000,0b11110,0b00001,0b00001,0b10001,0b01110}, /* 5 */
    {0b00110,0b01000,0b10000,0b11110,0b10001,0b10001,0b01110}, /* 6 */
    {0b11111,0b00001,0b00010,0b00100,0b01000,0b01000,0b01000}, /* 7 */
    {0b01110,0b10001,0b10001,0b01110,0b10001,0b10001,0b01110}, /* 8 */
    {0b01110,0b10001,0b10001,0b01111,0b00001,0b00010,0b01100}, /* 9 */
    {0b00000,0b00100,0b00100,0b00000,0b00100,0b00100,0b00000}, /* : */
    {0b00001,0b00010,0b00010,0b00100,0b01000,0b01000,0b10000}, /* / */
    {0b00000,0b00000,0b00000,0b11111,0b00000,0b00000,0b00000}, /* - */
    {0b00000,0b00000,0b00000,0b00000,0b00000,0b01100,0b01100}, /* . */
    {0b00100,0b00100,0b00100,0b00100,0b00100,0b00000,0b00100}  /* ! */
};

static int glyphIndex(char c) {
    if (c >= 'a' && c <= 'z') c = (char)(c - 32);
    if (c >= 'A' && c <= 'Z') return c - 'A';
    if (c >= '0' && c <= '9') return 26 + (c - '0');
    switch (c) {
        case ':': return 36;
        case '/': return 37;
        case '-': return 38;
        case '.': return 39;
        case '!': return 40;
        default:  return -1;
    }
}

static void drawGlyph(char ch, float x, float y, float s, unsigned int color) {
    int g = glyphIndex(ch);
    int row, col;
    if (g < 0) return;
    for (row = 0; row < 7; row++) {
        unsigned char bits = font5x7[g][row];
        col = 0;
        while (col < 5) {
            if (bits & (0x10 >> col)) {
                int start = col;
                while (col < 5 && (bits & (0x10 >> col))) col++;
                fillRect(x + start * s, y + row * s, (col - start) * s, s, color);
            } else {
                col++;
            }
        }
    }
}

static float textWidth(const char* str, float s) {
    return (float)strlen(str) * 6.0f * s - s;
}

static void drawText(const char* str, float x, float y, float s, unsigned int color) {
    for (; *str; str++) {
        drawGlyph(*str, x, y, s, color);
        x += 6.0f * s;
    }
}

/* texto com sombra */
static void drawTextShadow(const char* str, float x, float y, float s,
                            unsigned int color, unsigned int shadow) {
    drawText(str, x + s * 0.6f, y + s * 0.6f, s, shadow);
    drawText(str, x, y, s, color);
}

/* texto grande com "extrusao" 3D (varias copias deslocadas) */
static void drawTextExtruded(const char* str, float x, float y, float s,
                              unsigned int color, unsigned int side, int depth) {
    int k;
    for (k = depth; k >= 1; k--) {
        drawText(str, x + k, y + k, s, side);
    }
    drawText(str, x, y, s, color);
}

/* teia de aranha: raios saindo de (cx,cy) + aneis com curva "murcha" */
static void drawWeb(float cx, float cy, float a0, float a1, int rays, int rings,
                     float step, unsigned int color) {
    int maxLines = rays + rings * (rays - 1) * 2;
    ColorVertex* v = (ColorVertex*)sceGuGetMemory(2 * maxLines * sizeof(ColorVertex));
    int n = 0, i, r;
    float da = (a1 - a0) / (float)(rays - 1);

    for (i = 0; i < rays; i++) {
        float a = a0 + da * i;
        v[n].color = color; v[n].x = cx; v[n].y = cy; v[n].z = 0; n++;
        v[n].color = color;
        v[n].x = cx + cosf(a) * step * rings;
        v[n].y = cy + sinf(a) * step * rings;
        v[n].z = 0; n++;
    }
    for (r = 1; r <= rings; r++) {
        float rad = step * r;
        for (i = 0; i < rays - 1; i++) {
            float aA = a0 + da * i;
            float aB = a0 + da * (i + 1);
            float aM = (aA + aB) * 0.5f;
            float px0 = cx + cosf(aA) * rad, py0 = cy + sinf(aA) * rad;
            float px1 = cx + cosf(aB) * rad, py1 = cy + sinf(aB) * rad;
            float mx  = cx + cosf(aM) * rad * 0.90f;
            float my  = cy + sinf(aM) * rad * 0.90f;
            v[n].color = color; v[n].x = px0; v[n].y = py0; v[n].z = 0; n++;
            v[n].color = color; v[n].x = mx;  v[n].y = my;  v[n].z = 0; n++;
            v[n].color = color; v[n].x = mx;  v[n].y = my;  v[n].z = 0; n++;
            v[n].color = color; v[n].x = px1; v[n].y = py1; v[n].z = 0; n++;
        }
    }
    sceGuDrawArray(GU_LINES, V2D_FMT, n, 0, v);
}

static unsigned int hash3(unsigned int a, unsigned int b, unsigned int c) {
    unsigned int h = a * 73856093u ^ b * 19349663u ^ c * 83492791u;
    h ^= h >> 13;
    h *= 1274126177u;
    return h ^ (h >> 16);
}

/* skyline da cidade ao fundo, com janelas acesas */
static void drawSkyline(float groundY) {
    int i;
    for (i = 0; i < 16; i++) {
        float bx = i * 31.0f - 6.0f;
        float bw = 29.0f;
        float bh = 45.0f + (float)(hash3(i, 1, 7) % 7) * 15.0f;
        float by = groundY - bh;
        int wx, wy;
        fillRectV(bx, by, bw, bh, 0xFF241014, 0xFF120808);
        for (wy = 0; wy < (int)(bh / 11.0f) - 1; wy++) {
            for (wx = 0; wx < 3; wx++) {
                unsigned int h = hash3(i, wx + 3, wy + 11);
                if (h % 3 == 0) {
                    unsigned int c = (h & 0x100) ? 0xFF50D8FF : 0xFF3AB0F0;
                    fillRect(bx + 4 + wx * 8.5f, by + 6 + wy * 11.0f, 5, 6, c);
                }
            }
        }
    }
}

/* ------------------------------------------------------------------ */
/* Modo 3D                                                             */
/* ------------------------------------------------------------------ */
#define V3D_FMT (GU_COLOR_8888 | GU_VERTEX_32BITF | GU_TRANSFORM_3D)

/* chao verde (um grande quad) + grade, sem depth test (e sempre o mais
   distante). A grade da referencia visual pra ver a camera girando. */
static void drawFloor(void) {
    int i;
    ColorVertex* v;
    ColorVertex* g;
    const float S = 50.0f;
    unsigned int green = 0xFF339933; /* ABGR */
    unsigned int line  = 0xFF267326;

    sceGuDisable(GU_TEXTURE_2D);
    sceGuDisable(GU_DEPTH_TEST);

    v = (ColorVertex*)sceGuGetMemory(4 * sizeof(ColorVertex));
    v[0].color = green; v[0].x = -S; v[0].y = 0; v[0].z = -S;
    v[1].color = green; v[1].x =  S; v[1].y = 0; v[1].z = -S;
    v[2].color = green; v[2].x = -S; v[2].y = 0; v[2].z =  S;
    v[3].color = green; v[3].x =  S; v[3].y = 0; v[3].z =  S;
    sceGumDrawArray(GU_TRIANGLE_STRIP, V3D_FMT, 4, 0, v);

    g = (ColorVertex*)sceGuGetMemory(2 * 2 * 26 * sizeof(ColorVertex));
    for (i = 0; i < 26; i++) {
        float p = -50.0f + i * 4.0f;
        g[i * 4 + 0].color = line; g[i * 4 + 0].x = p;  g[i * 4 + 0].y = 0; g[i * 4 + 0].z = -S;
        g[i * 4 + 1].color = line; g[i * 4 + 1].x = p;  g[i * 4 + 1].y = 0; g[i * 4 + 1].z =  S;
        g[i * 4 + 2].color = line; g[i * 4 + 2].x = -S; g[i * 4 + 2].y = 0; g[i * 4 + 2].z = p;
        g[i * 4 + 3].color = line; g[i * 4 + 3].x =  S; g[i * 4 + 3].y = 0; g[i * 4 + 3].z = p;
    }
    sceGumDrawArray(GU_LINES, V3D_FMT, 2 * 2 * 26, 0, g);

    sceGuEnable(GU_DEPTH_TEST);
}

/* pilar colorido (marco de referencia no mapa) */
static void drawPillar(float cx, float cz, float half, float h, unsigned int color) {
    ColorVertex* v = (ColorVertex*)sceGuGetMemory(14 * sizeof(ColorVertex));
    float x0 = cx - half, x1 = cx + half, z0 = cz - half, z1 = cz + half;
    unsigned int top = color;
    unsigned int bot = shadeColor(color, 0.45f);

    sceGuDisable(GU_TEXTURE_2D);
    /* laterais: tira em volta */
    v[0].color = bot; v[0].x = x0; v[0].y = 0; v[0].z = z0;
    v[1].color = top; v[1].x = x0; v[1].y = h; v[1].z = z0;
    v[2].color = bot; v[2].x = x1; v[2].y = 0; v[2].z = z0;
    v[3].color = top; v[3].x = x1; v[3].y = h; v[3].z = z0;
    v[4].color = bot; v[4].x = x1; v[4].y = 0; v[4].z = z1;
    v[5].color = top; v[5].x = x1; v[5].y = h; v[5].z = z1;
    v[6].color = bot; v[6].x = x0; v[6].y = 0; v[6].z = z1;
    v[7].color = top; v[7].x = x0; v[7].y = h; v[7].z = z1;
    v[8].color = bot; v[8].x = x0; v[8].y = 0; v[8].z = z0;
    v[9].color = top; v[9].x = x0; v[9].y = h; v[9].z = z0;
    sceGumDrawArray(GU_TRIANGLE_STRIP, V3D_FMT, 10, 0, v);
    /* topo */
    {
        unsigned int t2 = shadeColor(color, 1.25f);
        v[10].color = t2; v[10].x = x0; v[10].y = h; v[10].z = z0;
        v[11].color = t2; v[11].x = x1; v[11].y = h; v[11].z = z0;
        v[12].color = t2; v[12].x = x0; v[12].y = h; v[12].z = z1;
        v[13].color = t2; v[13].x = x1; v[13].y = h; v[13].z = z1;
        sceGumDrawArray(GU_TRIANGLE_STRIP, V3D_FMT, 4, 0, v + 10);
    }
}

typedef struct { float x, z; unsigned int color; } Pillar;
static const Pillar pillars[] = {
    {  12.0f,  -8.0f, 0xFF3030E0 }, { -12.0f,  -8.0f, 0xFFE05030 },
    {  12.0f,   8.0f, 0xFF30D0F0 }, { -12.0f,   8.0f, 0xFFC03080 },
    {   0.0f, -16.0f, 0xFF3080F0 }, {   0.0f,  16.0f, 0xFFD0D030 },
    {  28.0f,   0.0f, 0xFF3030E0 }, { -28.0f,   0.0f, 0xFFE05030 },
    {   0.0f, -30.0f, 0xFF30D0F0 }, {   0.0f,  30.0f, 0xFFC03080 },
    {  25.0f,  25.0f, 0xFF3080F0 }, { -25.0f, -25.0f, 0xFFD0D030 },
    {  25.0f, -25.0f, 0xFFC03080 }, { -25.0f,  25.0f, 0xFF3080F0 }
};
#define PILLAR_COUNT ((int)(sizeof(pillars) / sizeof(pillars[0])))

/* ---- monta a pose atual (interpolando entre 2 frames) num buffer ---- */
static void blendPose(ModelVertex* dst, const ModelVertex* src, int vertCount,
                       int frameA, int frameB, float blend) {
    int i;
    for (i = 0; i < vertCount; i++) {
        const ModelVertex* a = &src[frameA * vertCount + i];
        const ModelVertex* b = &src[frameB * vertCount + i];
        dst[i].u = a->u;
        dst[i].v = a->v;
        dst[i].x = a->x + (b->x - a->x) * blend;
        dst[i].y = a->y + (b->y - a->y) * blend;
        dst[i].z = a->z + (b->z - a->z) * blend;
    }
}

/* escolhe clip/frames pelo estado e preenche bodyBuf/legsBuf */
static void buildPose(CharState state, float animTime) {
    const ModelVertex* bodySrc;
    const ModelVertex* legsSrc;
    float clipDur;
    int loopAnim = 1;
    int nFrames = ANIM_FRAMES;
    int lastIsEnd = 0;      /* 1 = a ultima pose e o fim do clipe (pulo) */
    float t, phase, blend;
    int frameA, frameB;

    switch (state) {
        case STATE_WALK:
            bodySrc = body_walk; legsSrc = legs_walk; clipDur = WALK_CLIP_DURATION;
            break;
        case STATE_PUNCH:
            bodySrc = body_punch; legsSrc = legs_punch; clipDur = PUNCH_CLIP_DURATION;
            loopAnim = 0;
            break;
        case STATE_JUMP:
            bodySrc = body_jump; legsSrc = legs_jump; clipDur = JUMP_CLIP_DURATION;
            loopAnim = 0; nFrames = JUMP_FRAMES; lastIsEnd = 1;
            break;
        default:
            bodySrc = body_idle; legsSrc = legs_idle; clipDur = IDLE_CLIP_DURATION;
            break;
    }

    t = loopAnim ? fmodf(animTime, clipDur) : animTime;
    if (t >= clipDur) t = clipDur - 0.0001f;
    if (t < 0.0f) t = 0.0f;

    phase = lastIsEnd ? (t / clipDur) * (float)(nFrames - 1)
                      : (t / clipDur) * (float)nFrames;
    frameA = (int)phase;
    if (frameA >= nFrames) frameA = nFrames - 1;
    frameB = loopAnim ? (frameA + 1) % nFrames
                      : (frameA + 1 < nFrames ? frameA + 1 : frameA);
    blend = phase - frameA;

    blendPose(bodyBuf, bodySrc, BODY_VERTEX_COUNT, frameA, frameB, blend);
    blendPose(legsBuf, legsSrc, LEGS_VERTEX_COUNT, frameA, frameB, blend);

    /* o GE le a memoria direto: garante que o cache da CPU foi escrito */
    sceKernelDcacheWritebackRange(bodyBuf, sizeof(bodyBuf));
    sceKernelDcacheWritebackRange(legsBuf, sizeof(legsBuf));
}

/* ---- desenha as duas partes do Homem-Aranha (corpo + pernas), cada uma com sua textura ---- */
static void drawSpidey(void) {
    sceGuEnable(GU_TEXTURE_2D);
    sceGuTexFunc(GU_TFX_REPLACE, GU_TCC_RGB);
    sceGuTexFilter(GU_LINEAR, GU_LINEAR);
    sceGuTexWrap(GU_CLAMP, GU_CLAMP);
    sceGuTexScale(1.0f, 1.0f);
    sceGuTexOffset(0.0f, 0.0f);

    sceGuTexMode(GU_PSM_5650, 0, 0, 0);
    sceGuTexImage(0, BODY_TEX_WIDTH, BODY_TEX_HEIGHT, BODY_TEX_WIDTH, body_texture);
    sceGumDrawArray(GU_TRIANGLES,
        GU_TEXTURE_32BITF | GU_VERTEX_32BITF | GU_TRANSFORM_3D | GU_INDEX_16BIT,
        BODY_INDEX_COUNT, body_indices, bodyBuf);

    sceGuTexImage(0, LEGS_TEX_WIDTH, LEGS_TEX_HEIGHT, LEGS_TEX_WIDTH, legs_texture);
    sceGumDrawArray(GU_TRIANGLES,
        GU_TEXTURE_32BITF | GU_VERTEX_32BITF | GU_TRANSFORM_3D | GU_INDEX_16BIT,
        LEGS_INDEX_COUNT, legs_indices, legsBuf);

    sceGuDisable(GU_TEXTURE_2D);
}

/* ---- flash branco de impacto do chute (quad centrado na origem do model) ---- */
static void drawPunchFlash(void) {
    ColorVertex* v;
    const float S = 0.10f;
    unsigned int white = 0xFFFFFFFF;

    sceGuDisable(GU_TEXTURE_2D);
    v = (ColorVertex*)sceGuGetMemory(4 * sizeof(ColorVertex));
    v[0].color = white; v[0].x = -S; v[0].y = -S; v[0].z = 0;
    v[1].color = white; v[1].x =  S; v[1].y = -S; v[1].z = 0;
    v[2].color = white; v[2].x = -S; v[2].y =  S; v[2].z = 0;
    v[3].color = white; v[3].x =  S; v[3].y =  S; v[3].z = 0;
    sceGumDrawArray(GU_TRIANGLE_STRIP, V3D_FMT, 4, 0, v);
}

/* ------------------------------------------------------------------ */
/* Tela inicial                                                        */
/* ------------------------------------------------------------------ */
static void renderTitle(float t) {
    const float groundY = 222.0f;
    int i;

    /* --- fundo 2D: ceu degrade, teia, cidade, chao --- */
    begin2D();
    fillRectV(0, 0, SCR_WIDTH, groundY, 0xFF3A0F10, 0xFF2A18B8);
    drawWeb(0.0f,   0.0f, 0.0f,               (float)M_PI * 0.5f, 8, 7, 34.0f, 0x60FFFFFF);
    drawWeb(480.0f, 0.0f, (float)M_PI * 0.5f, (float)M_PI,        8, 7, 34.0f, 0x60FFFFFF);
    drawSkyline(groundY);
    fillRectV(0, groundY, SCR_WIDTH, SCR_HEIGHT - groundY, 0xFF2A2A2A, 0xFF0C0C0C);
    fillRect(0, groundY, SCR_WIDTH, 2, 0xFF3838C8);
    for (i = 0; i < 8; i++) {
        fillRect(20.0f + i * 62.0f, 250.0f, 30, 3, 0x70A0A0A0);
    }

    /* --- Homem-Aranha girando de leve, no lado direito --- */
    end2D();
    buildPose(STATE_IDLE, t);

    sceGumMatrixMode(GU_PROJECTION);
    sceGumLoadIdentity();
    sceGumPerspective(60.0f, (float)SCR_WIDTH / (float)SCR_HEIGHT, 0.3f, 100.0f);

    {
        ScePspFVector3 eye    = { 0.0f, 1.13f, 3.0f };
        ScePspFVector3 center = { 0.0f, 1.13f, 0.0f };
        ScePspFVector3 up     = { 0.0f, 1.0f, 0.0f };
        ScePspFVector3 pos    = { 2.0f, 0.0f, 0.0f };

        sceGumMatrixMode(GU_VIEW);
        sceGumLoadIdentity();
        sceGumLookAt(&eye, &center, &up);

        sceGumMatrixMode(GU_MODEL);
        sceGumLoadIdentity();
        sceGumTranslate(&pos);
        sceGumRotateY(0.55f * sinf(t * 0.8f)); /* modelo olha pra +Z = pra camera */
        drawSpidey();
    }

    /* --- textos 2D por cima --- */
    begin2D();
    {
        const char* title = "SPIDEY";
        const char* sub   = "HOMEM-ARANHA 3D";
        const char* press = "APERTE START";
        const char* hint  = "X PULAR   QUADRADO CHUTAR   L R CAMERA";
        float tw = textWidth(title, 9.0f);
        float sw = textWidth(sub, 3.0f);
        float pw = textWidth(press, 3.0f);
        float hw = textWidth(hint, 1.0f);
        int a = 90 + (int)(165.0f * (0.5f + 0.5f * sinf(t * 5.0f)));
        unsigned int blink = ((unsigned int)a << 24) | 0x00FFFFFF;
        unsigned int blinkShadow = ((unsigned int)(a * 3 / 4) << 24) | 0x00000000;
        float tx = 24.0f;

        (void)tw;
        drawTextExtruded(title, tx, 30.0f, 9.0f, 0xFFFFFFFF, 0xFF20105A, 5);
        fillRectV(tx, 100.0f, sw + 8.0f, 3.0f, 0xFF3838E8, 0x003838E8);
        drawTextShadow(sub, tx, 110.0f, 3.0f, 0xFF00D8FF, 0xFF000000);

        drawTextShadow(press, 240.0f - pw * 0.5f - 40.0f, 236.0f, 3.0f, blink, blinkShadow);
        drawText(hint, 240.0f - hw * 0.5f, 263.0f, 1.0f, 0xFFB0B0B0);
    }
    end2D();
}

/* ------------------------------------------------------------------ */
/* Cutscene do Homem-Aranha (passo 5)                                  */
/*  camera de cinema: barras pretas, fade-in, camera baixa que gira e  */
/*  termina EXATAMENTE na posicao da camera do jogo (sem "pulo" na     */
/*  transicao). START pula a cutscene.                                 */
/*  Passo 7 (mortal + break dance) entra aqui: e so trocar o estado    */
/*  passado pro buildPose() em renderCutscene() conforme o tempo.      */
/* ------------------------------------------------------------------ */
#define CUTSCENE_DURATION 6.0f
#define LETTERBOX_H       34.0f

static float smooth01(float x) {
    if (x < 0.0f) x = 0.0f;
    if (x > 1.0f) x = 1.0f;
    return x * x * (3.0f - 2.0f * x);
}

static void cutsceneCamera(float t, ScePspFVector3* eye, ScePspFVector3* center) {
    float u = t / CUTSCENE_DURATION;
    float k;
    float theta, radius, height;
    if (u > 1.0f) u = 1.0f;
    k = 1.0f - smooth01(u);          /* 1 no comeco, 0 no fim */
    theta  = -1.1f * k;              /* orbita ao redor do Aranha */
    radius = 2.4f + 2.0f * k;        /* vem se aproximando */
    height = 1.2f - 0.75f * k;       /* comeca baixa (angulo heroico) */
    eye->x = sinf(theta) * radius;
    eye->y = height;
    eye->z = cosf(theta) * radius;
    center->x = 0.0f;
    center->y = 0.9f + 0.25f * k;
    center->z = 0.0f;
}

static void renderCutscene(float t) {
    ScePspFVector3 eye, center;
    ScePspFVector3 up = { 0.0f, 1.0f, 0.0f };
    int i;

    cutsceneCamera(t, &eye, &center);
    buildPose(STATE_IDLE, t);

    sceGumMatrixMode(GU_PROJECTION);
    sceGumLoadIdentity();
    sceGumPerspective(60.0f, (float)SCR_WIDTH / (float)SCR_HEIGHT, 0.3f, 200.0f);

    sceGumMatrixMode(GU_VIEW);
    sceGumLoadIdentity();
    sceGumLookAt(&eye, &center, &up);

    sceGumMatrixMode(GU_MODEL);
    sceGumLoadIdentity();
    drawFloor();

    for (i = 0; i < PILLAR_COUNT; i++) {
        sceGumMatrixMode(GU_MODEL);
        sceGumLoadIdentity();
        drawPillar(pillars[i].x, pillars[i].z, 0.6f, 4.0f, pillars[i].color);
    }

    /* Homem-Aranha de frente pra camera final (olha pra +Z) */
    sceGumMatrixMode(GU_MODEL);
    sceGumLoadIdentity();
    drawSpidey();

    /* ---- overlay 2D: barras de cinema, fade e legenda ---- */
    begin2D();
    {
        float barH = LETTERBOX_H * smooth01(t / 0.5f)
                   * (1.0f - smooth01((t - (CUTSCENE_DURATION - 0.7f)) / 0.7f));
        float fade = 1.0f - smooth01(t / 0.9f);

        if (barH > 0.5f) {
            fillRect(0.0f, 0.0f, SCR_WIDTH, barH, 0xFF000000);
            fillRect(0.0f, SCR_HEIGHT - barH, SCR_WIDTH, barH, 0xFF000000);
        }

        if (t > 1.2f && t < 4.8f && barH > 20.0f) {
            const char* cap = "HOMEM-ARANHA";
            float a = smooth01((t - 1.2f) / 0.6f) * (1.0f - smooth01((t - 4.2f) / 0.6f));
            unsigned int ia = (unsigned int)(a * 255.0f);
            float cw = textWidth(cap, 2.0f);
            drawTextShadow(cap, 240.0f - cw * 0.5f, SCR_HEIGHT - 26.0f, 2.0f,
                           (ia << 24) | 0x00FFFFFF, ((ia * 3 / 4) << 24));
        }
        if (barH > 20.0f) {
            drawText("START: PULAR", SCR_WIDTH - 82.0f, SCR_HEIGHT - 12.0f, 1.0f, 0xFF909090);
        }

        if (fade > 0.01f) {
            unsigned int fa = (unsigned int)(fade * 255.0f);
            fillRect(0.0f, 0.0f, SCR_WIDTH, SCR_HEIGHT, fa << 24);
        }
    }
    end2D();
}

/* ------------------------------------------------------------------ */
/* main                                                                */
/* ------------------------------------------------------------------ */
int main(void) {
    SetupCallbacks();
    prepareModel();

    void* fbp0 = (void*)0;
    void* fbp1 = (void*)(512 * 272 * 4);
    void* zbp  = (void*)(512 * 272 * 4 * 2);

    sceGuInit();
    sceGuStart(GU_DIRECT, list);
    sceGuDrawBuffer(GU_PSM_8888, fbp0, BUF_WIDTH);
    sceGuDispBuffer(SCR_WIDTH, SCR_HEIGHT, fbp1, BUF_WIDTH);
    sceGuDepthBuffer(zbp, BUF_WIDTH);
    sceGuOffset(2048 - (SCR_WIDTH / 2), 2048 - (SCR_HEIGHT / 2));
    sceGuViewport(2048, 2048, SCR_WIDTH, SCR_HEIGHT);
    sceGuDepthRange(0xc350, 0x2710);
    sceGuScissor(0, 0, SCR_WIDTH, SCR_HEIGHT);
    sceGuEnable(GU_SCISSOR_TEST);
    sceGuDepthFunc(GU_GEQUAL);
    sceGuEnable(GU_DEPTH_TEST);
    sceGuFrontFace(GU_CW);
    sceGuShadeModel(GU_SMOOTH);
    sceGuEnable(GU_CLIP_PLANES);
    sceGuFinish();
    sceGuSync(0, 0);

    sceCtrlSetSamplingCycle(0);
    sceCtrlSetSamplingMode(PSP_CTRL_MODE_ANALOG);

    sceDisplayWaitVblankStart();
    sceGuDisplay(GU_TRUE);

    /* ---- estado do jogo ---- */
    GameState gameState = GS_TITLE;
    float titleTime = 0.0f;

    float playerX = 0.0f, playerZ = 0.0f;
    float playerY = 0.0f;      /* base (chao = 0); a altura do pulo vem da animacao */
    float cutTime = 0.0f;      /* relogio da cutscene */
    float camLift = 0.0f;      /* camera acompanha o salto */

    /* yaw = para onde o corpo do personagem olha (0 = olha pra +Z).
       O modelo nasce olhando pra +Z, entao yaw = atan2(dirX, dirZ) */
    float yaw = (float)M_PI;         /* comeca de costas pra camera */
    float camYaw = 0.0f;             /* orbita da camera, controlada por L/R */

    const float moveSpeed   = 1.6f;  /* unidades por segundo */
    const float turnLerp    = 0.20f; /* suavidade do giro */
    const float camTurnRate = 2.2f;  /* rad/s ao segurar L ou R */
    const float jumpAnimSpeed = 1.25f; /* 1.0 = velocidade original do clipe de pulo */
    const float camDist     = 2.4f;
    const float camHeight   = 1.2f;

    /* ---- animacao ---- */
    CharState state = STATE_IDLE;
    float animTime = 0.0f;

    int prevButtons = 0;

    SceCtrlData pad;

    while (1) {
        float dt = 1.0f / 60.0f;

        sceCtrlReadBufferPositive(&pad, 1);

        if (gameState == GS_TITLE) {
            /* ---------------- TELA INICIAL ---------------- */
            titleTime += dt;

            if (((pad.Buttons & PSP_CTRL_START) && !(prevButtons & PSP_CTRL_START)) ||
                ((pad.Buttons & PSP_CTRL_CROSS) && !(prevButtons & PSP_CTRL_CROSS))) {
                gameState = GS_CUTSCENE;   /* START -> cutscene -> jogo */
                cutTime = 0.0f;
            }
            prevButtons = pad.Buttons;

            sceGuStart(GU_DIRECT, list);
            sceGuClearColor(0xFF553311);
            sceGuClearDepth(0);
            sceGuClear(GU_COLOR_BUFFER_BIT | GU_DEPTH_BUFFER_BIT);
            renderTitle(titleTime);
            sceGuFinish();
            sceGuSync(0, 0);

            sceDisplayWaitVblankStart();
            sceGuSwapBuffers();
            continue;
        }

        if (gameState == GS_CUTSCENE) {
            /* ---------------- CUTSCENE ---------------- */
            int skip = (pad.Buttons & PSP_CTRL_START) && !(prevButtons & PSP_CTRL_START);
            cutTime += dt;
            prevButtons = pad.Buttons;

            if (cutTime >= CUTSCENE_DURATION || (skip && cutTime > 0.3f)) {
                /* fim da cutscene: agora o personagem pode ser controlado.
                   A camera da cutscene termina igual a do jogo e o Aranha
                   continua olhando pra ela (yaw 0), entao nao tem "pulo". */
                gameState = GS_PLAY;
                playerX = 0.0f; playerZ = 0.0f; playerY = 0.0f;
                yaw = 0.0f; camYaw = 0.0f; camLift = 0.0f;
                state = STATE_IDLE; animTime = cutTime;
                continue;
            }

            sceGuStart(GU_DIRECT, list);
            sceGuClearColor(0xFF553311);
            sceGuClearDepth(0);
            sceGuClear(GU_COLOR_BUFFER_BIT | GU_DEPTH_BUFFER_BIT);
            renderCutscene(cutTime);
            sceGuFinish();
            sceGuSync(0, 0);

            sceDisplayWaitVblankStart();
            sceGuSwapBuffers();
            continue;
        }

        /* ---------------- JOGO ---------------- */

        /* camera: L gira pra esquerda, R gira pra direita */
        if (pad.Buttons & PSP_CTRL_LTRIGGER) camYaw -= camTurnRate * dt;
        if (pad.Buttons & PSP_CTRL_RTRIGGER) camYaw += camTurnRate * dt;
        if (camYaw >  (float)M_PI) camYaw -= 2.0f * (float)M_PI;
        if (camYaw < -(float)M_PI) camYaw += 2.0f * (float)M_PI;

        /* movimento: analogico (Lx/Ly) OU direcional (D-pad) */
        float ax = (pad.Lx - 128) / 128.0f;
        float ay = (pad.Ly - 128) / 128.0f;
        float amag = sqrtf(ax * ax + ay * ay);

        if (amag > 0.20f) {
            if (amag > 1.0f) { ax /= amag; ay /= amag; }
        } else {
            ax = 0.0f; ay = 0.0f;
            if (pad.Buttons & PSP_CTRL_UP)    ay -= 1.0f;
            if (pad.Buttons & PSP_CTRL_DOWN)  ay += 1.0f;
            if (pad.Buttons & PSP_CTRL_LEFT)  ax -= 1.0f;
            if (pad.Buttons & PSP_CTRL_RIGHT) ax += 1.0f;
            float dmag = sqrtf(ax * ax + ay * ay);
            if (dmag > 1.0f) { ax /= dmag; ay /= dmag; }
        }

        float mag = sqrtf(ax * ax + ay * ay);
        int moving = (mag > 0.15f);

        if (moving) {
            /* direcao no mundo RELATIVA A CAMERA:
               cima = pra onde a camera olha, direita = direita da tela */
            float cs = cosf(camYaw), sn = sinf(camYaw);
            float dirX = ax * cs - ay * sn;
            float dirZ = ax * sn + ay * cs;

            /* o personagem olha exatamente pra onde anda (frente do modelo = +Z) */
            float targetYaw = atan2f(dirX, dirZ);
            float diff = targetYaw - yaw;
            while (diff >  (float)M_PI) diff -= 2.0f * (float)M_PI;
            while (diff < -(float)M_PI) diff += 2.0f * (float)M_PI;
            yaw += diff * turnLerp;

            playerX += dirX * moveSpeed * dt;
            playerZ += dirZ * moveSpeed * dt;
        }

        if (playerX >  45.0f) playerX =  45.0f;
        if (playerX < -45.0f) playerX = -45.0f;
        if (playerZ >  45.0f) playerZ =  45.0f;
        if (playerZ < -45.0f) playerZ = -45.0f;

        /* pulo (X): toca o clipe de pulo (Jumping.fbx). A subida/descida
           vem da propria animacao, entao nao tem mais fisica de gravidade. */
        if ((pad.Buttons & PSP_CTRL_CROSS) && !(prevButtons & PSP_CTRL_CROSS) && state != STATE_JUMP) {
            state = STATE_JUMP;
            animTime = 0.0f;
        }

        /* chute (quadrado) */
        if ((pad.Buttons & PSP_CTRL_SQUARE) && !(prevButtons & PSP_CTRL_SQUARE) &&
            state != STATE_PUNCH && state != STATE_JUMP) {
            state = STATE_PUNCH;
            animTime = 0.0f;
        }

        prevButtons = pad.Buttons;

        /* maquina de estados de animacao */
        if (state == STATE_JUMP) {
            animTime += dt * jumpAnimSpeed;
            if (animTime >= JUMP_CLIP_DURATION) {
                state = moving ? STATE_WALK : STATE_IDLE;
                animTime = 0.0f;
            }
        } else if (state == STATE_PUNCH) {
            animTime += dt;
            if (animTime >= PUNCH_CLIP_DURATION) {
                state = moving ? STATE_WALK : STATE_IDLE;
                animTime = 0.0f;
            }
        } else {
            CharState wanted = moving ? STATE_WALK : STATE_IDLE;
            if (wanted != state) {
                state = wanted;
                animTime = 0.0f;
            } else {
                animTime += dt;
            }
        }

        buildPose(state, animTime);

        /* altura do pe mais baixo (> 0 quando esta no ar): a camera sobe junto */
        {
            int vi;
            float low = 1000.0f;
            for (vi = 0; vi < LEGS_VERTEX_COUNT; vi++) {
                if (legsBuf[vi].y < low) low = legsBuf[vi].y;
            }
            if (low < 0.0f) low = 0.0f;
            camLift += (low - camLift) * 0.2f;
        }

        /* camera em terceira pessoa orbitando o player */
        float camFwdX = sinf(camYaw);
        float camFwdZ = -cosf(camYaw);

        ScePspFVector3 eye    = { playerX - camFwdX * camDist,
                                  playerY + camHeight + camLift * 0.5f,
                                  playerZ - camFwdZ * camDist };
        ScePspFVector3 center = { playerX, playerY + 0.9f + camLift * 0.7f, playerZ };
        ScePspFVector3 up     = { 0.0f, 1.0f, 0.0f };

        /* frente do personagem (usada pro flash do chute) */
        float facingX = sinf(yaw);
        float facingZ = cosf(yaw);

        /* ---- desenho ---- */
        sceGuStart(GU_DIRECT, list);
        sceGuClearColor(0xFF553311); /* ceu (ABGR) */
        sceGuClearDepth(0);
        sceGuClear(GU_COLOR_BUFFER_BIT | GU_DEPTH_BUFFER_BIT);

        sceGumMatrixMode(GU_PROJECTION);
        sceGumLoadIdentity();
        sceGumPerspective(60.0f, (float)SCR_WIDTH / (float)SCR_HEIGHT, 0.3f, 200.0f);

        sceGumMatrixMode(GU_VIEW);
        sceGumLoadIdentity();
        sceGumLookAt(&eye, &center, &up);

        /* chao + grade */
        sceGumMatrixMode(GU_MODEL);
        sceGumLoadIdentity();
        drawFloor();

        /* pilares de referencia */
        {
            int i;
            for (i = 0; i < PILLAR_COUNT; i++) {
                sceGumMatrixMode(GU_MODEL);
                sceGumLoadIdentity();
                drawPillar(pillars[i].x, pillars[i].z, 0.6f, 4.0f, pillars[i].color);
            }
        }

        /* player */
        sceGumMatrixMode(GU_MODEL);
        sceGumLoadIdentity();
        {
            ScePspFVector3 pTrans = { playerX, playerY, playerZ };
            sceGumTranslate(&pTrans);
        }
        sceGumRotateY(yaw);
        drawSpidey();

        /* flash do impacto do chute, perto do fim da animacao (sempre de frente pra camera) */
        if (state == STATE_PUNCH && animTime >= PUNCH_CLIP_DURATION * 0.55f &&
            animTime <= PUNCH_CLIP_DURATION * 0.85f) {
            ScePspFVector3 fTrans = { playerX + facingX * 0.65f, playerY + 0.45f,
                                      playerZ + facingZ * 0.65f };
            sceGumMatrixMode(GU_MODEL);
            sceGumLoadIdentity();
            sceGumTranslate(&fTrans);
            sceGumRotateY(-camYaw);
            drawPunchFlash();
        }

        sceGuFinish();
        sceGuSync(0, 0);

        sceDisplayWaitVblankStart();
        sceGuSwapBuffers();
    }

    sceGuTerm();
    sceKernelExitGame();
    return 0;
}
