#ifndef BACKFLIP_DATA_H
#define BACKFLIP_DATA_H

#include "model_data.h"

/* Animacao de mortal para tras (Backflip.fbx do Mixamo) assada no Homem-Aranha, sem deslocamento (no lugar).
   32 poses igualmente espacadas (de 0 ate BACKFLIP_CLIP_DURATION, a ultima e o fim do clipe).
   Gerado do Backflip.fbx (Mixamo) com o mesmo processo do jump_data. */
#define BACKFLIP_FRAMES 32
#define BODY_BACKFLIP_COUNT (BODY_VERTEX_COUNT * BACKFLIP_FRAMES)
#define LEGS_BACKFLIP_COUNT (LEGS_VERTEX_COUNT * BACKFLIP_FRAMES)
#define BACKFLIP_CLIP_DURATION 2.150000f

extern ModelVertex body_backflip[BODY_BACKFLIP_COUNT];
extern ModelVertex legs_backflip[LEGS_BACKFLIP_COUNT];

#endif
