#ifndef FLAIR_DATA_H
#define FLAIR_DATA_H

#include "model_data.h"

/* Animacao de break dance (Flair.fbx do Mixamo) assada no Homem-Aranha, no lugar.
   20 poses igualmente espacadas (em loop: a pose N volta pra pose 0).
   Gerado do Flair.fbx (Mixamo) com o mesmo processo do jump_data. */
#define FLAIR_FRAMES 20
#define BODY_FLAIR_COUNT (BODY_VERTEX_COUNT * FLAIR_FRAMES)
#define LEGS_FLAIR_COUNT (LEGS_VERTEX_COUNT * FLAIR_FRAMES)
#define FLAIR_CLIP_DURATION 1.000000f

extern ModelVertex body_flair[BODY_FLAIR_COUNT];
extern ModelVertex legs_flair[LEGS_FLAIR_COUNT];

#endif
